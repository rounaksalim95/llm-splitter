const e="contextMenuSelectedText";export{e as S};
